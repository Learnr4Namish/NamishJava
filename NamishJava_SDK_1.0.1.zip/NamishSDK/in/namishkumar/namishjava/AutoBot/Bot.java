package in.namishkumar.namishjava.AutoBot;

public class Bot {

}
