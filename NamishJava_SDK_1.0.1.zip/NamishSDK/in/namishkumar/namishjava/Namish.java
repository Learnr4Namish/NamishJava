package in.namishkumar.namishjava;

import java.io.PrintStream;

public class Namish {
    final static String BaseVersion = "1.0.1";
    public static String Version = BaseVersion;

    public static void main(String[] args) {

    }

    public static void showVersion() {
        System.out.println(
                "Welcome to NamishJava 1.0.1. For more information, please visit https://namishjava.namishkumar.in/");
    }
}
