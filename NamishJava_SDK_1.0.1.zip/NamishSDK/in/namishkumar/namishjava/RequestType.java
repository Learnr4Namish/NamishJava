package in.namishkumar.namishjava;

public class RequestType {
    public static void main(String[] args) {

    }

    public static int POST() {
        return 8585;
    }

    public static int GET() {
        return 8586;
    }

    public static int PUT() {
        return 8587;
    }

}
