package in.namishkumar.namishjava;

import javax.swing.Action;

public class Errors {
    public static void main(String[] args) {

    }

    public static void ThrowError(int ErrorType, Object ErrorMessage) {
        throw ErrorMessage;
    }

}
