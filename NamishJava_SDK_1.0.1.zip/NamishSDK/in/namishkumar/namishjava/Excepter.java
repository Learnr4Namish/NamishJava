package in.namishkumar.namishjava;

public class Excepter {

}
