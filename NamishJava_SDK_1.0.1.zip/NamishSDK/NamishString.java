public class NamishString {

}
