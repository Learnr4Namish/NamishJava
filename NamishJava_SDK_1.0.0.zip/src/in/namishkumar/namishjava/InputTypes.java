package in.namishkumar.namishjava;
public class InputTypes{
    public static void main() {

    }

    public static int String() {
        return 8080;
    }

    public static int Number() {
        return 8081;
    }

    public static int Boolean() {
        return 8082;
    }

    public static int Float() {
        return 8083;
    }
}
