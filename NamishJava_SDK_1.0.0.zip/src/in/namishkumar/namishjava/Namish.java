package in.namishkumar.namishjava;

import java.io.PrintStream;

public class Namish {
    public static void main(String[] args) {
        
    }

    public static void showVersion() {
        System.out.println("Welcome to NamishJava 1.0.0. For more information, please visit https://namishjava.namishkumar.in/");
    }
}
