package in.namishkumar.namishjava;
import java.time.LocalDate;
public class NamishTime {
    LocalDate TimeObj = LocalDate.now();
    public static void main(String[] args) {

    }
  
    
    
}
