import in.namishkumar.namishjava.Terminal;
import in.namishkumar.namishjava.NamishInput;
import in.namishkumar.namishjava.NamishMath;
public class sample_console {
     public static void main(String[] args) {
          Terminal.writeLine(NamishInput.readLine("What's your Name?"));
     }
}
